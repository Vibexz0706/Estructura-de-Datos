/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package TAREAS.tarea1;

/**
 *
 * @author VIBEXZ
 */
//import static TAREAS.tarea1.EJE2.anagrama;
import static TAREAS.tarea1.EJER4.recurSum;
import java.util.Arrays;
import javax.swing.JOptionPane;

public class tarea1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        //--------------------------------------------------------------EJERCICIO 1---------------------------------------
        //System.out.println(EJER1.invertir(12336));
        //--------------------------------------------------------------EJERCICIO 2----------------------------------------
        /*
        
        Solo falta hacerle el bucle 
        
        String palabra = "hola";
        System.out.println(EJE2.eje2(palabra));
        */
        
        
        //System.out.println(anagrama(palabra,palabra.length()-1));
         
        //--------------------------------------------------------------EJERCICIO 3----------------------------------------
        /*
         System.out.print("Digite el tamaño ");
         int tamaño = new java.util.Scanner(System.in).nextInt();
         int vector []= new int [tamaño];
         
         System.out.println(Arrays.toString(EJE2.devolver(vector, tamaño)));
         System.out.println(EJE2.valorMay(vector, tamaño, tamaño));
         */
        //---------------------------------------------------------------EJERCICIO 4-----------------------------------------
        /*
        
        int n = 10;
        System.out.println(recurSum(n));
        
         */
        
        //---------------------------------------------------------------EJERCICIO 5------------------------------------------
        /*
        int d;
        String val;
        val = JOptionPane.showInputDialog("Digite el numero de la tabla de multiplicar vas a utilizar");
        d = Integer.parseInt(val);
        System.out.println(EJE5.tabla(10, d));

         */
    }

}
